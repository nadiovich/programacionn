package logica;

import java.util.ArrayList;


public class manejador {
	
	private ArrayList<Estudiante> estudiantes;
	private ArrayList<Profesor> profesores;
	private ArrayList<Bibliotecario> bibliotecario;
	private ArrayList<Prestamos> prestamoss;
	
	
	
	
	public ArrayList<Estudiante> getEstudiantes() {
		return estudiantes;
	}
	public void setEstudiantes(ArrayList<Estudiante> estudiantes) {
		this.estudiantes = estudiantes;
	}
	public ArrayList<Profesor> getProfesores() {
		return profesores;
	}
	public void setProfesores(ArrayList<Profesor> profesores) {
		this.profesores = profesores;
	}
	public ArrayList<Bibliotecario> getBibliotecario() {
		return bibliotecario;
	}
	public void setBibliotecario(ArrayList<Bibliotecario> bibliotecario) {
		this.bibliotecario = bibliotecario;
	}
	public ArrayList<Prestamos> getPrestamoss() {
		return prestamoss;
	}
	public void setPrestamoss(ArrayList<Prestamos> prestamoss) {
		this.prestamoss = prestamoss;
	}

}
