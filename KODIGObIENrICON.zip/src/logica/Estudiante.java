package logica;


public class Estudiante extends Usuarios {

	private int IDe;
	
	Estudiante(int ID, int CI, String nombre, String apellido, String mail, String password, int IDe){
		super(ID, CI, nombre, apellido, mail, password);
		this.IDe = IDe;
		 
	}

	public int getIDe() {
		return IDe;
	}

	public void setIDe(int iDe) {
		IDe = iDe;
	}
}
