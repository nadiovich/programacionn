package logica;

public class Bibliotecario extends Usuarios{
	
	private int IDb;
	
	Bibliotecario(int ID, int CI, String nombre, String apellido, String mail, String password, int IDb){
		super(ID, CI, nombre, apellido, mail, password);
		this.IDb = IDb;
	}

	public int getIDb() {
		return IDb;
	}

	public void setIDb(int iDb) {
		IDb = iDb;
	}
}
