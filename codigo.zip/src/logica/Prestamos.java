package logica;

public class Prestamos {

}
