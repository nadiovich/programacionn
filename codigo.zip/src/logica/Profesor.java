package logica;

public class Profesor extends Usuarios{
	
	private int IDp;
	
	Profesor(int ID, int CI, String nombre, String apellido, String mail, String password, int IDp){
		super(ID, CI, nombre, apellido, mail, password);
		this.IDp = IDp;
	}

	public int getIDp() {
		return IDp;
	}

	public void setIDp(int iDp) {
		IDp = iDp;
	}

}
