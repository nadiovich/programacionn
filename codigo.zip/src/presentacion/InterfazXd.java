package presentacion;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JButton;
import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JComboBox;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JMenu;
import javax.swing.JCheckBoxMenuItem;
import javax.swing.JPasswordField;

public class InterfazXd extends JFrame {

	private JPanel contentPane;
	private JTextField ingresarCi;
	private JTextField ingresarId;
	private JTextField ingresarContra;
	private JTextField IngresarNombre;
	private JTextField IngresarApellido;
	private JTextField IngresarCi;
	private JTextField IngresarId;
	private JPasswordField passwordField;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					InterfazXd frame = new InterfazXd();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public InterfazXd() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 475, 324);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
	
		
		JPanel crearUsuarioPanel = new JPanel();
		crearUsuarioPanel.setBounds(0, 0, 459, 285);
		contentPane.add(crearUsuarioPanel);
		crearUsuarioPanel.setLayout(null);
		crearUsuarioPanel.setVisible(false);
		
		JLabel crearUsuTitulo = new JLabel("CREAR USUARIO");
		crearUsuTitulo.setFont(new Font("Segoe UI Semilight", Font.BOLD, 24));
		crearUsuTitulo.setBounds(129, 22, 194, 21);
		crearUsuarioPanel.add(crearUsuTitulo);
		
		JLabel NombreText = new JLabel("Nombre:");
		NombreText.setFont(new Font("Tahoma", Font.PLAIN, 13));
		NombreText.setBounds(144, 62, 54, 14);
		crearUsuarioPanel.add(NombreText);
		
		JLabel ApellidoText = new JLabel("Apellido:");
		ApellidoText.setFont(new Font("Tahoma", Font.PLAIN, 13));
		ApellidoText.setBounds(143, 84, 55, 14);
		crearUsuarioPanel.add(ApellidoText);
		
		JLabel CiText = new JLabel("C.I.:");
		CiText.setFont(new Font("Tahoma", Font.PLAIN, 13));
		CiText.setBounds(167, 106, 31, 14);
		crearUsuarioPanel.add(CiText);
		
		JLabel IdText = new JLabel("ID:");
		IdText.setFont(new Font("Tahoma", Font.PLAIN, 13));
		IdText.setBounds(175, 128, 23, 14);
		crearUsuarioPanel.add(IdText);
		
		JLabel TipoText = new JLabel("Tipo:");
		TipoText.setFont(new Font("Tahoma", Font.PLAIN, 13));
		TipoText.setBounds(162, 172, 36, 14);
		crearUsuarioPanel.add(TipoText);
		
		JLabel ContraText = new JLabel("Contrase\u00F1a:");
		ContraText.setFont(new Font("Tahoma", Font.PLAIN, 13));
		ContraText.setBounds(123, 150, 75, 14);
		crearUsuarioPanel.add(ContraText);
		
		IngresarNombre = new JTextField();
		IngresarNombre.setBounds(210, 62, 96, 14);
		crearUsuarioPanel.add(IngresarNombre);
		IngresarNombre.setColumns(10);
		
		IngresarApellido = new JTextField();
		IngresarApellido.setBounds(210, 84, 96, 14);
		crearUsuarioPanel.add(IngresarApellido);
		IngresarApellido.setColumns(10);
		
		IngresarCi = new JTextField();
		IngresarCi.setBounds(210, 106, 96, 14);
		crearUsuarioPanel.add(IngresarCi);
		IngresarCi.setColumns(10);
		
		IngresarId = new JTextField();
		IngresarId.setBounds(210, 128, 96, 14);
		crearUsuarioPanel.add(IngresarId);
		IngresarId.setColumns(10);
		
		
		JButton btnRegistrar = new JButton("REGISTRAR");
		btnRegistrar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
			}
		});
		btnRegistrar.setBounds(332, 228, 89, 21);
		crearUsuarioPanel.add(btnRegistrar);
		
		JPanel panelcito1 = new JPanel();
		panelcito1.setBounds(142, 191, 181, 28);
		crearUsuarioPanel.add(panelcito1);
		panelcito1.setLayout(null);
		
		JLabel OrientacionText1 = new JLabel("Orientaci\u00F3n:");
		OrientacionText1.setFont(new Font("Tahoma", Font.PLAIN, 13));
		OrientacionText1.setBounds(10, 9, 75, 14);
		panelcito1.add(OrientacionText1);
		
		JComboBox Orientacion = new JComboBox();
		Orientacion.setBounds(86, 9, 65, 16);
		panelcito1.add(Orientacion);
		Orientacion.setToolTipText("");
		Orientacion.addItem("TIC");
		Orientacion.addItem("ADM"); 
		
		
		JPanel panelcito2 = new JPanel();
		panelcito2.setLayout(null);
		panelcito2.setBounds(142, 208, 181, 28);
		crearUsuarioPanel.add(panelcito2);
		
		JLabel OrientacionText2 = new JLabel("Orientaci\u00F3n:");
		OrientacionText2.setFont(new Font("Tahoma", Font.PLAIN, 13));
		OrientacionText2.setBounds(10, 9, 75, 14);
		panelcito2.add(OrientacionText2);
		
		JComboBox Orientacion2 = new JComboBox();
		Orientacion2.setBounds(86, 9, 65, 16);
		panelcito2.add(Orientacion2);
		Orientacion2.setToolTipText("");
		Orientacion2.addItem("TIC");
		Orientacion2.addItem("ADM"); 
		Orientacion2.addItem("TIC & ADM"); 
		
		
		JPanel ingresarPanel = new JPanel();
		ingresarPanel.setBounds(0, 0, 459, 285);
		contentPane.add(ingresarPanel);
		ingresarPanel.setLayout(null);
		ingresarPanel.setVisible(false);
		
		JLabel ingresarTitulo = new JLabel("INGRESAR");
		ingresarTitulo.setFont(new Font("Segoe UI Semilight", Font.BOLD, 26));
		ingresarTitulo.setBounds(164, 43, 133, 23);
		ingresarPanel.add(ingresarTitulo);
		
		JLabel ciText = new JLabel("C.I.:");
		ciText.setFont(new Font("Tahoma", Font.PLAIN, 16));
		ciText.setBounds(163, 96, 33, 14);
		ingresarPanel.add(ciText);
		
		JLabel idText = new JLabel("ID:");
		idText.setFont(new Font("Tahoma", Font.PLAIN, 16));
		idText.setBounds(172, 130, 23, 14);
		ingresarPanel.add(idText);
		
		ingresarCi = new JTextField();
		ingresarCi.setBounds(209, 92, 101, 20);
		ingresarPanel.add(ingresarCi);
		ingresarCi.setColumns(10);
		
		ingresarId = new JTextField();
		ingresarId.setBounds(209, 126, 101, 20);
		ingresarPanel.add(ingresarId);
		ingresarId.setColumns(10);
		
		JButton ingresarUsu = new JButton("INGRESAR");
		ingresarUsu.setBounds(331, 225, 89, 23);
		ingresarPanel.add(ingresarUsu);
		
		
		JLabel contraText = new JLabel("Contrase\u00F1a:");
		contraText.setFont(new Font("Tahoma", Font.PLAIN, 16));
		contraText.setBounds(110, 164, 86, 14);
		ingresarPanel.add(contraText);
		
		ingresarContra = new JTextField();
		ingresarContra.setBounds(209, 160, 101, 20);
		ingresarPanel.add(ingresarContra);
		ingresarContra.setColumns(10);
		
		JPanel biblanimaPanel = new JPanel();
		biblanimaPanel.setBounds(0, 0, 459, 285);
		contentPane.add(biblanimaPanel);
		biblanimaPanel.setLayout(null);
		biblanimaPanel.setVisible(true);
		
		JLabel biblanimaText = new JLabel("BIBL\u00C1NIMA");
		biblanimaText.setBounds(160, 45, 140, 23);
		biblanimaText.setFont(new Font("Segoe UI Semilight", Font.BOLD, 26));
		biblanimaPanel.add(biblanimaText);
		
		JLabel bienvenida = new JLabel("Bienvenido/a :)");
		bienvenida.setBounds(175, 103, 114, 14);
		bienvenida.setFont(new Font("Tahoma", Font.PLAIN, 16));
		biblanimaPanel.add(bienvenida);
		
		JLabel pregunta = new JLabel("\u00BFQuiere registrarse o ingresar?");
		pregunta.setBounds(118, 151, 224, 23);
		pregunta.setFont(new Font("Tahoma", Font.PLAIN, 16));
		biblanimaPanel.add(pregunta);
		
		
		JButton registrarme = new JButton("REGISTRARME");
		registrarme.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				biblanimaPanel.setVisible(false);
				crearUsuarioPanel.setVisible(true);                                    
				panelcito1.setVisible(false);
				panelcito2.setVisible(false);
				ingresarPanel.setVisible(false);
			}
		});
		registrarme.setBounds(45, 211, 124, 23);
		biblanimaPanel.add(registrarme);
		
		
		JButton ingresar1 = new JButton("INGRESAR");
		ingresar1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				biblanimaPanel.setVisible(false);
				crearUsuarioPanel.setVisible(false);                                    
				panelcito1.setVisible(false);
				panelcito2.setVisible(false);
				ingresarPanel.setVisible(true);
			}
		});
		ingresar1.setBounds(289, 211, 124, 23);
		biblanimaPanel.add(ingresar1);
		
		
		JButton cancelarInresar = new JButton("CANCELAR");
		cancelarInresar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				biblanimaPanel.setVisible(true);
				crearUsuarioPanel.setVisible(false);                                    
				panelcito1.setVisible(false);
				panelcito2.setVisible(false);
				ingresarPanel.setVisible(false);
			}
		});
		cancelarInresar.setBounds(39, 225, 89, 23);
		ingresarPanel.add(cancelarInresar);
		
		
		JButton btnCancelar = new JButton("CANCELAR");
		btnCancelar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				biblanimaPanel.setVisible(true);
				crearUsuarioPanel.setVisible(false);                                    
				panelcito1.setVisible(false);
				panelcito2.setVisible(false);
				ingresarPanel.setVisible(false);
			}
		});
		btnCancelar.setBounds(39, 228, 89, 21);
		crearUsuarioPanel.add(btnCancelar);
		
	
		
		
		
		/*JMenuItem mntmProfesor = new JMenuItem("Profesor/a");
		mnTipos.add(mntmProfesor);
		
		JMenuItem mntmBibliotecario = new JMenuItem("Bibliotecario");
		mnTipos.add(mntmBibliotecario); */
		
		JMenuItem mntmEstudiante = new JMenuItem("Estudiante");
		mntmEstudiante.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				biblanimaPanel.setVisible(false);
				crearUsuarioPanel.setVisible(true);                                    
				panelcito1.setVisible(true);
				panelcito2.setVisible(false);
				ingresarPanel.setVisible(false);
			}
		});
		
		
		JMenu mnTipos = new JMenu("tipos");
		mnTipos.setBounds(210, 167, 96, 21);
		crearUsuarioPanel.add(mnTipos);
		mnTipos.add(mntmEstudiante);
		
		passwordField = new JPasswordField();
		passwordField.setBounds(210, 150, 96, 14);
		crearUsuarioPanel.add(passwordField);
	}
}
