package logica;

import java.sql.Connection;
import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Scanner;

import logica.Usuario;
import persistencia.Conn;
import logica.Prestamo;

public class Manejador {

	private ArrayList<Usuario> usuarioss = new ArrayList<>();
	private ArrayList<Libro> libross = new ArrayList<>();
	ArrayList<Usuario> prestamos = new ArrayList<>();
	static Scanner in = new Scanner(System.in);


	public Manejador() {
		Conn connect = new Conn();
		Connection con = connect.conectarMySQL();
		Statement n;
		try {
			n = con.createStatement();
			ResultSet rs = n.executeQuery("SELECT * FROM data");
			while(rs.next())
				System.out.println(rs.getString(2));
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public void altaUsuario(int CI, String nombre, String apellido, String mail, String password, int id,
			Orientacion orient, TipoUsuario tipouser) throws SQLException {
		Conn connect = new Conn();
		Connection con = connect.conectarMySQL();

		Statement n = null;
		try {
			n = con.createStatement();
			n.executeUpdate("INSERT INTO usuario (nombre,apellido,mail,ci,password) " + " VALUES('" + nombre + "','"
					+ apellido + "','" + mail + "'," + CI + ",'" + password + "');");

		} catch (SQLException e) {
			e.printStackTrace();
		}

		switch (tipouser) {
		case ESTUDIANTE:
			Estudiante est = new Estudiante(CI, id, nombre, apellido, mail, password, orient);
			this.usuarioss.add(est);
			n.executeUpdate("INSERT INTO Estudiante (CI, orient) " + " VALUES(" + CI + ",'" + orient + "';");

			break;
		case PROFESOR:
			Profesor prof = new Profesor(CI, id, nombre, apellido, mail, password, orient);
			this.usuarioss.add(prof);
			n.executeUpdate("INSERT INTO Profesor (CI, orient) " + " VALUES(" + CI + ",'" + orient + "';");
			break;
		case BIBLIOTECARIO:

			Bibliotecario bibl = new Bibliotecario(CI, id, nombre, apellido, mail, password);
			this.usuarioss.add(bibl);
			n.executeUpdate("INSERT INTO Bibliotecario (CI) " + " VALUES(" + CI + ",'" + orient + "';");

			break;

		}
	}

	public Usuario consultaUsuario(int id) {
		
		Usuario ret = null;
		int i = 0;
		//es para buscar el usuario, vos ingresas el id lo busca
		while (i < usuarioss.size() && usuarioss.get(i).getId() != id) {
			i++;
		}
		// si encuentra a el usuario, te lo muestra
		if (i < usuarioss.size()) {
			ret = usuarioss.get(i);
		}

		return ret;

	}

	public Usuario buscarUsuario(int CI) {
		int i = 0;
		Usuario ret = null;

		while (i < usuarioss.size() && usuarioss.get(i).getCI() != CI) {
			i++;
		}

		if (i < usuarioss.size()) {
			ret = usuarioss.get(i);
		}

		return ret;

	}

	public void listarUsuariosPosiblesParaModificar() throws SQLException {
		listarUsuariosExistentes();
		int ci = 0;
		Usuario usuar = buscarUsuario(ci);
		if (usuar == null) {
			// mensaje de error
			// deja que el bibliotecario edite los datos del usuario ARREGLAR LO DE LA FECHA ASDFGHJKHGFDSASDFGHJHGFDSDFGH
		} else {
			this.modificarDatosUsuario(1234567, "nononono", "lol", "dja@jsa", "pass", Orientacion.TIC);
		}
		listarUsuariosExistentes();
	}

	public void modificarDatosUsuario(int CI, String nombre, String apellido, String mail, String password,
			Orientacion or) {
		Usuario user = buscarUsuario(CI);
		user.editar(CI, nombre, apellido, mail, password, or);
	}

	public void listarUsuariosExistentes() throws SQLException {
		for (int i = 0; i < usuarioss.size(); i++) {
			System.out.println(usuarioss.get(i).getCI() + " - " + usuarioss.get(i).getNombre());
		}
		 Statement n = null;
		n.executeQuery ("SELECT * FROM alumnos");
	
	}

	public void listasPrestamos() throws SQLException {
		for (int i = 0; i < prestamos.size(); i++) {
			System.out.println("Prestamo numero " + prestamos.get(i).getId());
		}
		Statement s = null;
		s.executeQuery("SELECT * FROM alumnos");
		
	}

	public void altaPrestamo(int CI, int id, int ISBN, Date fechaSolicitado, Date fechaDevolucion,
			boolean devuelto) {
		int i = 0;
		while (i < usuarioss.size() && usuarioss.get(i).getCI() != CI) {
			i++;
		}
		Prestamo prest = new Prestamo(id, fechaSolicitado, fechaDevolucion, devuelto, usuarioss.get(i));
		this.prestamos.add(prest);
	}
 
	public void consultarPrestamo(int idUsuario) {
		System.out.println("Prestamos de: ");
		for (int i = 0; i < prestamos.size(); i++) {
			if (prestamos.get(i).getId() == idUsuario) {
				System.out.println("Prestamo numero " + prestamos.get(i).getId());
			}
		}
	}

	public void altaLibro(String autor, int AnioPublic, int nroEdicion, String editorial, String descripcion,
			String cantEjemplares, boolean disponibilidad, int ISBN, String genero, String link,
			String codLibro, String titulo) {
		int i = 0;
		while (i < libross.size() && libross.get(i).getISBN() != ISBN) {
			i++;
		}
		Libro librukis = new Libro( autor, AnioPublic, nroEdicion, editorial, descripcion, cantEjemplares,
				disponibilidad, ISBN, genero, link, codLibro, titulo);
		libross.add(librukis);
	}

	public void listarLibro() {
		for (int i = 0; i < libross.size(); i++) {
			System.out.println("Libro numero " + libross.get(i).getISBN());
			
		}
//		 n.executeQuery ("SELECT * FROM libross");
		

	}

	

	public void altaUsuario(String text, String text2, String text3, int parseInt, String valueOf, Orientacion tic,
			Orientacion adm, Orientacion admytic, TipoUsuario estudiante) {
		// TODO Auto-generated method stub
		
	}
}
	
	
	

