package logica;

public class Bibliotecario extends Usuario {
	public Bibliotecario (int id, int CI, String nombre, String apellido, String mail, String password) {
		super(id, CI, nombre, apellido, mail, password, null);
	
	}
}

//no necesitas getters ni setters