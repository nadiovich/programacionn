package logica;

public enum Orientacion {
	TIC, ADM, ADMYTIC

}
