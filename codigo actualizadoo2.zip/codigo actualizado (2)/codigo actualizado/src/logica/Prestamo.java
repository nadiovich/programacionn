package logica;

import java.util.Date;

import logica.Usuario;

public class Prestamo {

	private int id;
	private Date fechaSolicitado;
	private Date fechaDevolucion;
	private boolean devuelto;
	private Usuario usuarioo;
	
	public Prestamo(int id2, Date fechaSolicitado2, Date fechaDevolucion2, boolean devuelto2, Usuario usuarioo) {

		this.id = id2;
		this.fechaDevolucion = fechaDevolucion2;
		this.fechaSolicitado = fechaSolicitado2;
		this.devuelto = devuelto2;
		this.usuarioo = usuarioo;
	}
	
	public int getId() {
		return this.id;
	}

	public int getUserId() {
		return this.usuarioo.getId();
	}
	
}

