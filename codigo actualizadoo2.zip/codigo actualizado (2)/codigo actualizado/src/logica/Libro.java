package logica;


public class Libro {
	private String autor;
	private int AnioPublic;
	private int nroEdicion;
	private String editorial;
	private String descripcion;
	private String cantEjemplares;
	private boolean disponibilidad;
	private int ISBN;
	private String genero;
	private String link;
	private String codLibro;
	private String titulo;
	
	
	public Libro(String autor, int AnioPublic, int nroEdicion, String editorial, String descripcion,
			String cantEjemplares, boolean disponibilidad, int ISBN, String genero, String link,
			String codLibro, String titulo) {
		super();
		this.autor = autor;
		this.AnioPublic = AnioPublic;
		this.nroEdicion = nroEdicion;
		this.editorial = editorial;
		this.descripcion = descripcion;
		this.cantEjemplares = cantEjemplares;
		this.disponibilidad = disponibilidad;
		this.ISBN = ISBN;
		this.genero = genero;
		this.link = link;
		this.codLibro = codLibro;
		this.titulo = titulo;
	}


	public String getAutor() {
		return autor;
	}


	public void setAutor(String autor) {
		this.autor = autor;
	}


	public int getAnioPublic() {
		return AnioPublic;
	}


	public void setAnioPublic(int AnioPublic) {
		this.AnioPublic = AnioPublic;
	}


	public int getNroEdicion() {
		return nroEdicion;
	}


	public void setNroEdicion(int nroEdicion) {
		this.nroEdicion = nroEdicion;
	}


	public String getEditorial() {
		return editorial;
	}


	public void setEditorial(String editorial) {
		this.editorial = editorial;
	}


	public String getDescripcion() {
		return descripcion;
	}


	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}


	public String getCantEjemplares() {
		return cantEjemplares;
	}


	public void setCantEjemplares(String cantEjemplares) {
		this.cantEjemplares = cantEjemplares;
	}


	public boolean isdisponibilidad() {
		return disponibilidad;
	}


	public void setdisponibilidad(boolean disponibilidad) {
		this.disponibilidad = disponibilidad;
	}


	public int getISBN() {
		return ISBN;
	}


	public void setISBN(int ISBN) {
		this.ISBN = ISBN;
	}


	public String getGenero() {
		return genero;
	}


	public void setGenero(String genero) {
		this.genero = genero;
	}


	public String getlink() {
		return link;
	}


	public void setlink(String link) {
		this.link = link;
	}


	public String getcodLibro() {
		return codLibro;
	}


	public void setcodLibro(String codLibro) {
		this.codLibro = codLibro;
	}


	public String getTitulo() {
		return titulo;
	}


	public void setTitulo(String titulo) {
		this.titulo = titulo;
	}
	
	
	
	
	

}
