package logica;

public enum TipoUsuario {
	PROFESOR, ESTUDIANTE, BIBLIOTECARIO

}
