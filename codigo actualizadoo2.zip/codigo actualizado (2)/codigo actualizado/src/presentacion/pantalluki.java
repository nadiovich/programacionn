package presentacion;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JButton;
import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JComboBox;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JMenu;
import javax.swing.JCheckBoxMenuItem;
import javax.swing.JPasswordField;

public class pantalluki extends JFrame {

	private JPanel contentPane;
	private JTextField ingresarCi;
	private JTextField ingresarId;
	private JTextField ingresarContra;
	private JTextField IngresarNombre;
	private JTextField IngresarApellido;
	private JTextField IngresarCi;
	private JTextField IngresarId;
	private JPasswordField passwordField;
	private JTextField ingresarMail;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					pantalluki frame = new pantalluki();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public pantalluki() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 475, 324);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		

	
		
		JPanel crearUsuarioPanel = new JPanel();
		crearUsuarioPanel.setBounds(0, 21, 459, 264);
		contentPane.add(crearUsuarioPanel);
		crearUsuarioPanel.setLayout(null);
		crearUsuarioPanel.setVisible(false);
		
		JLabel crearUsuTitulo = new JLabel("CREAR USUARIO");
		crearUsuTitulo.setFont(new Font("Segoe UI Semilight", Font.BOLD, 24));
		crearUsuTitulo.setBounds(129, 22, 194, 21);
		crearUsuarioPanel.add(crearUsuTitulo);
		
		JLabel NombreText = new JLabel("Nombre:");
		NombreText.setFont(new Font("Tahoma", Font.PLAIN, 13));
		NombreText.setBounds(60, 62, 54, 14);
		crearUsuarioPanel.add(NombreText);
		
		JLabel ApellidoText = new JLabel("Apellido:");
		ApellidoText.setFont(new Font("Tahoma", Font.PLAIN, 13));
		ApellidoText.setBounds(60, 103, 55, 14);
		crearUsuarioPanel.add(ApellidoText);
		
		JLabel CiText = new JLabel("C.I.:");
		CiText.setFont(new Font("Tahoma", Font.PLAIN, 13));
		CiText.setBounds(225, 62, 31, 14);
		crearUsuarioPanel.add(CiText);
		
		JLabel IdText = new JLabel("ID:");
		IdText.setFont(new Font("Tahoma", Font.PLAIN, 13));
		IdText.setBounds(249, 87, 23, 14);
		crearUsuarioPanel.add(IdText);
		
		JLabel TipoText = new JLabel("Tipo:");
		TipoText.setFont(new Font("Tahoma", Font.PLAIN, 13));
		TipoText.setBounds(126, 183, 36, 14);
		crearUsuarioPanel.add(TipoText);
		
		JLabel ContraText = new JLabel("Contrase\u00F1a:");
		ContraText.setFont(new Font("Tahoma", Font.PLAIN, 13));
		ContraText.setBounds(213, 112, 75, 14);
		crearUsuarioPanel.add(ContraText);
		
		IngresarNombre = new JTextField();
		IngresarNombre.setBounds(112, 79, 96, 14);
		crearUsuarioPanel.add(IngresarNombre);
		IngresarNombre.setColumns(10);
		
		IngresarApellido = new JTextField();
		IngresarApellido.setBounds(112, 104, 96, 14);
		crearUsuarioPanel.add(IngresarApellido);
		IngresarApellido.setColumns(10);
		
		IngresarCi = new JTextField();
		IngresarCi.setBounds(266, 63, 96, 14);
		crearUsuarioPanel.add(IngresarCi);
		IngresarCi.setColumns(10);
		
		IngresarId = new JTextField();
		IngresarId.setBounds(266, 84, 96, 14);
		crearUsuarioPanel.add(IngresarId);
		IngresarId.setColumns(10);
		
		
		JButton btnRegistrar = new JButton("REGISTRAR");
		btnRegistrar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
			}
		});
		btnRegistrar.setBounds(332, 228, 89, 21);
		crearUsuarioPanel.add(btnRegistrar);
		
		
		JButton btnCancelar = new JButton("CANCELAR");
		btnCancelar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				biblanimaPanel.setVisible(true);
				crearUsuarioPanel.setVisible(false);                                    
				ingresarPanel.setVisible(false);
			}
		});
		btnCancelar.setBounds(39, 228, 89, 21);
		crearUsuarioPanel.add(btnCancelar);
		
		passwordField = new JPasswordField();
		passwordField.setBounds(288, 113, 96, 14);
		crearUsuarioPanel.add(passwordField);
		
		JComboBox comboBox = new JComboBox();
		comboBox.setBounds(172, 181, 82, 20);
		crearUsuarioPanel.add(comboBox);
		
		JComboBox comboBox_1 = new JComboBox();
		comboBox_1.setBounds(264, 181, 82, 20);
		crearUsuarioPanel.add(comboBox_1);
		
		JLabel mailText = new JLabel("Mail:");
		mailText.setFont(new Font("Tahoma", Font.PLAIN, 13));
		mailText.setBounds(76, 129, 31, 14);
		crearUsuarioPanel.add(mailText);
		
		ingresarMail = new JTextField();
		ingresarMail.setBounds(112, 129, 96, 14);
		crearUsuarioPanel.add(ingresarMail);
		ingresarMail.setColumns(10);
		
		JMenuBar menuBar = new JMenuBar();
		menuBar.setBounds(0, 0, 459, 21);
		contentPane.add(menuBar);
		
		JMenu altaMenu = new JMenu("Alta");
		menuBar.add(altaMenu);
		
		
		
		JMenuItem altaPrstamo = new JMenuItem("Pr\u00E9stamo");
		altaMenu.add(altaPrstamo);
		
		JMenuItem altaNotificacin = new JMenuItem("Notificaci\u00F3n");
		altaMenu.add(altaNotificacin);
		
		JMenuItem altaLibro = new JMenuItem("Libro");
		altaMenu.add(altaLibro);
		
		JMenu listarMenu = new JMenu("Listar");
		menuBar.add(listarMenu);
		
		JMenuItem listarUsuario = new JMenuItem("Usuario");
		listarMenu.add(listarUsuario);
		
		JMenuItem listarPrstamo = new JMenuItem("Pr\u00E9stamo");
		listarMenu.add(listarPrstamo);
		
		JMenuItem listarLibros = new JMenuItem("Libros");
		listarMenu.add(listarLibros);
		
		JMenu consultaMenu = new JMenu("Consulta");
		menuBar.add(consultaMenu);
		
		JMenuItem consultaUsuario = new JMenuItem("Usuario");
		consultaMenu.add(consultaUsuario);
		
		JMenuItem consultaPrstamos = new JMenuItem("Pr\u00E9stamos");
		consultaMenu.add(consultaPrstamos);
		
		JMenu editarMenu = new JMenu("Editar");
		menuBar.add(editarMenu);
		
		JMenuItem editarUsuario = new JMenuItem("Usuario");
		editarMenu.add(editarUsuario);
		
		JMenu buscarMenu = new JMenu("Buscar");
		menuBar.add(buscarMenu);
		
		JMenuItem buscarUsuario = new JMenuItem("Usuario");
		buscarMenu.add(buscarUsuario);
		
		JMenu darDeBajaMenu = new JMenu("Dar de baja");
		menuBar.add(darDeBajaMenu);
		
		JMenuItem darDeBajaPrstamos = new JMenuItem("Pr\u00E9stamos");
		darDeBajaMenu.add(darDeBajaPrstamos);
		
		JPanel biblanimaPanel = new JPanel();
		biblanimaPanel.setBounds(0, 21, 459, 264);
		contentPane.add(biblanimaPanel);
		biblanimaPanel.setLayout(null);
		biblanimaPanel.setVisible(true);
		
		JLabel biblanimaText = new JLabel("BIBL\u00C1NIMA");
		biblanimaText.setBounds(121, 45, 202, 48);
		biblanimaText.setFont(new Font("Segoe UI Semibold", Font.BOLD, 36));
		biblanimaPanel.add(biblanimaText);
		
		JLabel bienvenida = new JLabel("Bienvenida :)");
		bienvenida.setBounds(165, 115, 114, 14);
		bienvenida.setFont(new Font("Tahoma", Font.PLAIN, 16));
		biblanimaPanel.add(bienvenida);
		
		JLabel label = new JLabel("");
		label.setBounds(146, 160, 161, 78);
		biblanimaPanel.add(label);
		
		
		JPanel ingresarPanel = new JPanel();
		ingresarPanel.setBounds(0, 21, 459, 264);
		contentPane.add(ingresarPanel);
		ingresarPanel.setLayout(null);
		ingresarPanel.setVisible(false);
		
		JLabel ingresarTitulo = new JLabel("INGRESAR");
		ingresarTitulo.setFont(new Font("Segoe UI Semilight", Font.BOLD, 26));
		ingresarTitulo.setBounds(164, 43, 133, 23);
		ingresarPanel.add(ingresarTitulo);
		
		JLabel ciText = new JLabel("C.I.:");
		ciText.setFont(new Font("Tahoma", Font.PLAIN, 16));
		ciText.setBounds(163, 96, 33, 14);
		ingresarPanel.add(ciText);
		
		JLabel idText = new JLabel("ID:");
		idText.setFont(new Font("Tahoma", Font.PLAIN, 16));
		idText.setBounds(172, 130, 23, 14);
		ingresarPanel.add(idText);
		
		ingresarCi = new JTextField();
		ingresarCi.setBounds(209, 92, 101, 20);
		ingresarPanel.add(ingresarCi);
		ingresarCi.setColumns(10);
		
		ingresarId = new JTextField();
		ingresarId.setBounds(209, 126, 101, 20);
		ingresarPanel.add(ingresarId);
		ingresarId.setColumns(10);
		
		JButton ingresarUsu = new JButton("INGRESAR");
		ingresarUsu.setBounds(331, 225, 89, 23);
		ingresarPanel.add(ingresarUsu);
		
		
		JLabel contraText = new JLabel("Contrase\u00F1a:");
		contraText.setFont(new Font("Tahoma", Font.PLAIN, 16));
		contraText.setBounds(110, 164, 86, 14);
		ingresarPanel.add(contraText);
		
		ingresarContra = new JTextField();
		ingresarContra.setBounds(209, 160, 101, 20);
		ingresarPanel.add(ingresarContra);
		ingresarContra.setColumns(10);
		
		
		JButton cancelarInresar = new JButton("CANCELAR");
		cancelarInresar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				biblanimaPanel.setVisible(true);                                 
				ingresarPanel.setVisible(false);
				crearUsuarioPanel.setVisible(false);
			}
		});
		cancelarInresar.setBounds(39, 225, 89, 23);
		ingresarPanel.add(cancelarInresar);
		
		JMenuItem altaUsuario = new JMenuItem("Usuario");
		altaUsuario.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				biblanimaPanel.setVisible(false);
				ingresarPanel.setVisible(false);
				crearUsuarioPanel.setVisible(true);
				}
		});
		altaMenu.add(altaUsuario);
	}
}
